import os

import requests


def get_repos_stats(username: str) -> list[dict]:
    if not username or not username.strip():
        raise ValueError('GitHub username is required')

    url = f'https://api.github.com/users/{username.strip()}/repos'
    headers = {'Accept': 'application/vnd.github+json', 'User-Agent': 'github-stats-homework'}
    token = os.getenv('GITHUB_TOKEN')
    if token:
        headers['Authorization'] = f'Bearer {token}'

    stats = []
    with requests.Session() as session:
        while url:
            response = session.get(url, headers=headers, params={'per_page': 100} if url.endswith('/repos') else None, timeout=20)
            response.raise_for_status()
            repositories = response.json()
            if not isinstance(repositories, list):
                raise ValueError('Unexpected GitHub API response')
            for repo in repositories:
                stats.append({
                    'name': repo['name'],
                    'stars': repo['stargazers_count'],
                    'forks': repo['forks_count'],
                    'language': repo['language'],
                })
            url = response.links.get('next', {}).get('url')
    return stats
