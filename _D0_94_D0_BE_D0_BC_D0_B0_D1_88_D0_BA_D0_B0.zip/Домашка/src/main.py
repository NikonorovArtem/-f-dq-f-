import os

from dotenv import load_dotenv

from src.functions import get_repos_stats
from src.postgres_db import PostgresDB


def main():
    load_dotenv()
    username = os.getenv('GITHUB_USERNAME', 'skypro-008')
    config = {
        'dbname': os.getenv('POSTGRES_DB', 'postgres'),
        'user': os.getenv('POSTGRES_USER', 'postgres'),
        'password': os.getenv('POSTGRES_PASSWORD'),
        'host': os.getenv('POSTGRES_HOST', 'localhost'),
        'port': os.getenv('POSTGRES_PORT', '5432'),
    }
    if not config['password']:
        raise ValueError('Set POSTGRES_PASSWORD in the .env file')

    stats = get_repos_stats(username)
    with PostgresDB(**config) as db:
        db.insert_data(stats)
        for repo in db.get_data(5, 'forks'):
            print(repo)
        filename = db.export_to_json()

    print(f'Saved {len(stats)} repositories to PostgreSQL and {filename}')


if __name__ == '__main__':
    main()
