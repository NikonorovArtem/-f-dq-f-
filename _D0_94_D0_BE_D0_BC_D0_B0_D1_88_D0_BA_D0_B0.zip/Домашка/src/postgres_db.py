import json
from pathlib import Path

import psycopg2
from psycopg2 import sql


class PostgresDB:
    def __init__(self, dbname: str, user: str, password: str, host: str = 'localhost', port: str = '5432', table_name: str = 'repos_stats'):
        self.conn = psycopg2.connect(dbname=dbname, user=user, password=password, host=host, port=port)
        self.table_name = table_name
        self._create_table()

    def _create_table(self):
        with self.conn:
            with self.conn.cursor() as cur:
                cur.execute(sql.SQL('''
                    CREATE TABLE IF NOT EXISTS {} (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL UNIQUE,
                        stars INTEGER NOT NULL,
                        forks INTEGER NOT NULL,
                        language VARCHAR(255)
                    )
                ''').format(sql.Identifier(self.table_name)))

    def insert_data(self, stats: list[dict]):
        statement = sql.SQL('''
            INSERT INTO {} (name, stars, forks, language)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (name) DO UPDATE
            SET stars = EXCLUDED.stars,
                forks = EXCLUDED.forks,
                language = EXCLUDED.language
        ''').format(sql.Identifier(self.table_name))
        with self.conn:
            with self.conn.cursor() as cur:
                for stat in stats:
                    cur.execute(statement, (stat['name'], stat['stars'], stat['forks'], stat['language']))

    def get_data(self, count: int, sort_by: str = 'name') -> list[dict]:
        if count < 0:
            raise ValueError('count must be non-negative')
        if sort_by not in ('name', 'language', 'stars', 'forks'):
            sort_by = 'name'
        direction = sql.SQL('DESC') if sort_by in ('stars', 'forks') else sql.SQL('ASC')
        query = sql.SQL('SELECT name, stars, forks, language FROM {} ORDER BY {} {} NULLS LAST, name ASC LIMIT %s').format(
            sql.Identifier(self.table_name), sql.Identifier(sort_by), direction
        )
        with self.conn.cursor() as cur:
            cur.execute(query, (count,))
            rows = cur.fetchall()
        return [dict(zip(('name', 'stars', 'forks', 'language'), row)) for row in rows]

    def export_to_json(self, filename: str | None = None):
        query = sql.SQL('SELECT id, name, stars, forks, language FROM {} ORDER BY id').format(sql.Identifier(self.table_name))
        with self.conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchall()
        result = [dict(zip(('id', 'name', 'stars', 'forks', 'language'), row)) for row in rows]
        path = Path(filename or f'{self.table_name}.json')
        path.write_text(json.dumps(result, ensure_ascii=False, indent=4), encoding='utf-8')
        return path

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
